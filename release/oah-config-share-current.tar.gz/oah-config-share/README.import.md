# OpenAgentHarness Shared Config

This archive contains shareable OAH configuration exported from:

- Exported at: `2026-05-11T09:11:15Z`

## What Is Included

- `config/`
- `models/`
- `tools/`
- `skills/`
- `scripts/`
- `runtimes/`
- top-level README/version metadata when present

## What Is Excluded

- `workspaces/`
- `state/`
- `logs/`
- `run/` and local API tokens
- `versions/`
- `bin/`
- `.oah-local*`
- local install/build/check folders

## Import

Install OpenAgentHarness first, then initialize the target home and overlay the shared configuration:

```sh
export OAH_HOME="$HOME/.openagentharness"
oah daemon init
tar -xzf "oah-config-share-current.tar.gz" -C /tmp
cp -R /tmp/oah-config-share/config /tmp/oah-config-share/models /tmp/oah-config-share/tools /tmp/oah-config-share/skills "$OAH_HOME"/
cp -R /tmp/oah-config-share/runtimes "$OAH_HOME"/
oah daemon restart
```

If this archive was exported with redaction enabled, secret-like values were replaced
with `<REDACTED>`; each recipient must set their own provider keys before model calls work.
