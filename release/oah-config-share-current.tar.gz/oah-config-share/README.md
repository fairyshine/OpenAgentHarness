# OpenAgentHarness Home

This directory is the unified local `OAH_HOME` and default `OAH_DEPLOY_ROOT` used by OAP daemon testing and local OAH stack workflows.

## Layout

- `config/`: deployment profiles for daemon, Docker Compose, and Kubernetes
- `models/`: platform model config YAML files
- `runtimes/`: workspace initialization templates
- `tools/`: tool config and tool server definitions
- `skills/`: reusable skill packages
- `workspaces/`: optional workspace data for object-storage sync
- `scripts/sync_to_minio.py`: syncs the asset directories into the MinIO bucket

The old `source/` layout has been flattened. Current OAH scripts still support legacy `source/` roots, but this home uses the preferred layout.

## Config Profiles

- `config/daemon.yaml`: OAP local single-user daemon profile, using SQLite shadow storage, local disk paths, and embedded execution.
- `config/server.docker.yaml`: OAH Docker Compose profile used by `pnpm local:up`.
- `config/kubernetes.server.yaml`: OAH Kubernetes server config source for ConfigMap or Helm values.

For local development, you can leave `OAH_DEPLOY_ROOT` unset. `pnpm local:up` and `pnpm storage:sync` default to `OAH_HOME`, then `~/.openagentharness`. To make the root explicit:

```bash
export OAH_HOME="$HOME/.openagentharness"
export OAH_DEPLOY_ROOT="$OAH_HOME"
```

## How Sync Works

From the OAH repo root:

```bash
pnpm storage:sync
```

The sync script maps local directories to bucket prefixes:

| Local directory | Bucket prefix | Purpose |
| --- | --- | --- |
| `workspaces/` | `workspace/` | Workspace runtime data |
| `runtimes/` | `runtime/` | Workspace runtimes |
| `models/` | `model/` | Model config YAML files |
| `tools/` | `tool/` | Tool config and tool server definitions |
| `skills/` | `skill/` | Reusable skill packages |

Workspace sync is opt-in:

```bash
pnpm storage:sync -- --include-workspaces
```

For first startup, `pnpm local:up` waits for MinIO and runs one sync automatically.

## Operational Rule

Edit test data in the top-level asset directories only. Docker volumes hold actual MinIO and runtime state; those should not be copied back into this root.
