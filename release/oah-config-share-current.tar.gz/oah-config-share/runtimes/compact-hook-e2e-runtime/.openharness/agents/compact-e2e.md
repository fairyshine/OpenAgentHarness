---
mode: primary
description: Compact hook e2e agent
model: workspace/compact-e2e
tools:
  native: []
  actions: []
  skills: []
  external: []
switch: []
subagents: []
---

Reply with exactly OK.
