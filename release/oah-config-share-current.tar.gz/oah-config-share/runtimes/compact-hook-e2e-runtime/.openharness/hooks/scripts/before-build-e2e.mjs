import { writeFileSync } from "node:fs";
let input = "";
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => { input += chunk; });
process.stdin.on("end", () => {
  writeFileSync("./before-build-e2e-log.json", input);
  process.stdout.write(JSON.stringify({ continue: true }));
});
